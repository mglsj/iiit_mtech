"""Lab 07 -- NumPy & pandas on soil spectra.

Fill in the 10 functions below. This file is autograded: keep the function
names and parameters as they are, and return your answers (don't just print
them).

Run `python lab07.py` to try every function on the data in ./data.
Before submitting, rename this file to <roll_no>.py (e.g. 20231110XX.py).
"""
import numpy as np
import pandas as pd


# ---------------------------------------------------------------- pandas --

def load_data(spectra_path, targets_path):
    """Task 1 (2 marks).

    Read both CSV files and return the tuple (spectra, targets):
      * spectra: indexed by the sample ID (the `sample` column); one float
        column per wavelength, named '350', '351', ..., '2500'.
      * targets: default integer index (0, 1, 2, ...); the `SOIL` column stays a
        column; every '-' in the file becomes NaN, so all lab-property columns
        are numeric (float).
    """
    raise NotImplementedError


def missing_report(targets):
    """Task 2 (2 marks).

    Return a Series whose index is the column names of `targets` that have
    at least one missing value, and whose values are the number of missing
    values in that column. Sort it by count, largest first. Columns with no
    missing values must not appear.
    """
    raise NotImplementedError


def top_oc_samples(targets, n=5):
    """Task 3 (2 marks).

    Return a DataFrame with exactly the columns ['SOIL', 'OC'] holding the
    n samples with the highest organic carbon (OC), highest first. Rows with
    missing OC are ignored.
    """
    raise NotImplementedError


def texture_class(targets):
    """Task 4 (2 marks).

    Return a Series of strings, one per row of `targets` and with the same
    index, using these rules in this order:
      'unknown' if CLAI or SAND is missing
      'sandy'   if SAND >= 70
      'clayey'  if CLAI >= 40
      'loamy'   otherwise
    """
    raise NotImplementedError


def site_summary(targets):
    """Task 5 (2 marks).

    The site of a sample is the run of capital letters at the start of its
    SOIL ID ('A1' -> 'A', 'EC12' -> 'EC').

    Return a DataFrame with one row per site, indexed by the site name and
    sorted alphabetically, with exactly the columns
      n     number of rows (samples) of that site
      clay  mean CLAI   (ignore missing values)
      sand  mean SAND   (ignore missing values)
      oc    mean OC     (ignore missing values)
    with the means rounded to 2 decimals.
    """
    raise NotImplementedError


def merge_spectra_targets(spectra, targets, cols):
    """Task 6 (2 marks).

    Attach the lab properties listed in `cols` (e.g. ['CLAI', 'OC']) to each
    spectrum. Keep only the samples present in BOTH tables.

    Return a DataFrame indexed by sample ID whose columns are all the spectra
    columns followed by `cols`, in that order (no SOIL column).
    """
    raise NotImplementedError


# ----------------------------------------------------------------- NumPy --
# In Tasks 7-10, X is a 2-D float ndarray (samples x wavelengths) and
# wavelengths is a 1-D int ndarray of the matching wavelengths in nm.

def strongest_absorption(X, wavelengths, lo, hi):
    """Task 7 (2 marks).

    Considering only the wavelengths w with lo <= w <= hi, return the
    wavelength (an int, in nm, NOT an array position) at which the mean
    spectrum (the mean over all samples) is lowest.
    """
    raise NotImplementedError


def standardize(X):
    """Task 8 (2 marks).

    Return a new array of the same shape in which every column has been
    standardized: (value - column mean) / column standard deviation.
    Use the population standard deviation (ddof=0, NumPy's default).
    You may assume no column is constant. Do not change X itself.
    """
    raise NotImplementedError


def band_depth(X, wavelengths, left, centre, right):
    """Task 9 (2 marks).

    For every sample, return the depth of the absorption band at `centre`
    as a 1-D array of length X.shape[0]:

        continuum = R_left + (R_right - R_left) * (centre - left) / (right - left)
        depth     = 1 - R_centre / continuum

    where R_w is that sample's reflectance at wavelength w.
    left < centre < right are wavelengths present in `wavelengths`.
    """
    raise NotImplementedError


def target_correlation(X, y):
    """Task 10 (2 marks).

    y is a 1-D float array with one lab value per sample (row of X); it may
    contain NaN. Ignoring the samples where y is NaN, return a 1-D array of
    length X.shape[1] whose j-th entry is the Pearson correlation between
    column j of X and y.
    """
    raise NotImplementedError


# ------------------------------------------------------------ try it out --

if __name__ == "__main__":
    spectra, targets = load_data("data/spectra.csv", "data/targets.csv")
    print("spectra", spectra.shape, " targets", targets.shape)
    print(missing_report(targets), "\n")
    print(top_oc_samples(targets), "\n")
    print(texture_class(targets).value_counts(), "\n")
    print(site_summary(targets), "\n")

    soil = merge_spectra_targets(spectra, targets, ["CLAI", "OC"])
    print("merged", soil.shape)

    X = spectra.to_numpy()
    wavelengths = spectra.columns.astype(int).to_numpy()
    print("strongest absorption 1300-2500nm:", strongest_absorption(X, wavelengths, 1300, 2500))
    print("standardized column means ~0:", np.allclose(standardize(X).mean(axis=0), 0))
    print("clay band depth, first 3 samples:", band_depth(X, wavelengths, 2150, 2206, 2250)[:3])

    Xs = soil[spectra.columns].to_numpy()
    r = target_correlation(Xs, soil["OC"].to_numpy())
    print("corr with OC at 800nm:", r[wavelengths == 800])
